#ifndef _PROCLIST_H_INCLUDED_
#define _PROCLIST_H_INCLUDED_

typedef struct procList pList;
typedef struct procNode pNode;

/*
 * pList_create returns a new pList with a null root
 *         NULL if not (failed to allocate)
 */
pList *pList_create(void);

/*
 * pList_insert_stdin fills the list with pNodes created from parsed stdin
 */
void pList_insert_stdin(pList *list);

/*
 * pList_insert_node inserts a node 'node' to the list with provided root 'root'
 */
pNode * pList_insert_node(pNode * root, pNode * node);

/*
 * pList_run runs every program in a pList 'list'
 */
void pList_run(pList *list);

#endif /* _PROCLIST_H_INCLUDED_ */
