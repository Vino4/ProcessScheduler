#include "procNode.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "p1fxns.h"

struct procNode
{
    char ** argvData ;
    char * pathData ;
    pNode * next;
    long PID;
    int argc;

};

/*
 * pNode_create creates a pNode structure from `progPath` & `progArgv`
 * `progPath' is expected to be a reference to a sring holding the path to the program file
 * `progArgv' is expected to be a reference to an array of srings holding arguments of the program
 * returns pointer to pNode structure if successful,
 *         NULL if not (failed to run program)
 */
pNode *pNode_create(char buf[], int argc){
	char * ptr = buf;
	printf("Creating new node...\n");
	pNode * newNode = (pNode*) malloc(sizeof(pNode));
	printf("Allocated newNode\n");
	printf("received buffer: %s\n", ptr);

	int i, index;
	for(i = 0; i < argc; i++){
		index = p1strchr(ptr, ' ');
		printf("detected a space at index (%d)\n", index);
		ptr += index;
		printf("char before termination '%c'\n", *ptr);	
		*ptr = '\0';
		printf("char after termination '%c'\n", *ptr);	
		index++;
		ptr++;
		printf("remaining args: %s\n", ptr);




		/*
		if (progArgv[i] != NULL){
			newNode->argvData[i] = malloc(strlen(progArgv[i]) + 1);
			printf("Allocated argvData->pathData[%d]\n", i);
			strcpy(newNode->argvData[i], progArgv[i]);
		} else {
			newNode->argvData[i] = NULL;
		}
		printf("initialized argvData->pathData[%d]: %s\n", i, newNode->argvData[i]);
		*/
	}
	printf("All arguments are successfuly parsed.\n");
	ptr = buf; //reset pointer
	printf("first argument length: %d\n", strlen(ptr) + 1);
	newNode->pathData = malloc(strlen(ptr) + 1); 
	printf("Allocated newNode->pathData with enough space for: %d characters\n", strlen(ptr) + 1);

	strcpy(newNode->pathData, ptr); 
	printf("intialized newNode->pathData: %s\n", newNode->pathData);
	argc++; //to include the program path as the 0th argument
	newNode->argvData = (char**) calloc(argc +1, sizeof(char*));
	printf("Allocated newNode->argvData with enough space for %d arguments.\n", argc +1);//leave one space to hold the null terminator of argv[] for execvp

	newNode->argvData[0] = malloc(strlen(ptr) + 1); 
	printf("Allocated newNode->argvData[0] with enough space for: %d characters\n", strlen(ptr) + 1);

	strcpy(newNode->argvData[0], ptr); 
	printf("intialized newNode->argvData[0]: %s\n", newNode->argvData[0]);

	for(i = 1; i < argc; i++){
		index = strlen(ptr) + 1;
		ptr += index;
		printf("next arg: %s\n", ptr);
		newNode->argvData[i] = malloc(strlen(ptr) + 1); 
		printf("Allocated newNode->argvData[%d] with enough space for: %d characters\n", i, strlen(ptr) + 1);

		strcpy(newNode->argvData[i], ptr); 
		printf("intialized newNode->argvData[%d]: %s\n", i, newNode->argvData[i]);
		index++;
		ptr++;
	}

	newNode->argvData[argc] = NULL; 
	printf("Assigned newNode->argvData[%d] to NULL\n", argc);

	newNode->next = NULL;
	newNode->PID = -1;
	newNode->argc = argc;

};

/*
 * pNode_getNext returns a reference to the node following provided reference 'node'
 *         NULL if no next available (no nodes remaining)
 */
pNode *pNode_getNext(pNode *node){
	return node->next;
};

/*
 * pNode_setNext sets a reference to the node 'next' at the node with provided reference 'node'
 */
void pNode_setNext(pNode *node, pNode *next){
	node->next = next;
};

/*
 * pNode_getArgc returns the "node"'s number of arguments
 */
int pNode_getArgc(pNode *node){
	return node->argc;
}


/*
 * pNode_getPID returns the "node"'s process ID
 *         (-1) if no process ID is asscociated with the program (program is not on)
 */
long pNode_getPID(pNode *node){
	return node->PID;
};

/*
 * pNode_setPID sets the "node"'s process ID
 */
void pNode_setPID(pNode *node, long PID){
	node->PID = PID;
};

/*
 * pNode_getArgv returns the "node"'s arguments reference in the form of a NULL-Terminated array of strings (char **)
 *		with the format: {"Knock, knock.", "Who’s there?", "very long pause….", "Java.", NULL}
 *         NULL if no arguments available
 */
char ** pNode_getArgv(pNode *node){
	return node->argvData;
};

/*
 * pNode_getArgv returns the "node"'s path reference in the form of a string (char *) with the format: "x/y/z/a.out"
 *         NULL if no path is available
 */
char * pNode_getPath(pNode *node){
	return node->pathData;
};

/*
 * runs a proccess and associates the proper PID with it
 */
void pNode_run(pNode *node){

	pid_t parent = getpid();
	pid_t pid = fork();

	if (pid == -1){
	    printf("Error: Fork failed.\n");
	} else if (pid > 0) {
	    int status;
	    waitpid(pid, &status, 0);
	} else if (pid == 0){
		printf("CHILD: running %s ...", pNode_getArgv(node)[0]);
		int errX = execvp(pNode_getArgv(node)[0], pNode_getArgv(node));
		printf("CHILD:errX: %d\n", errX);
		execvp(pNode_getArgv(node)[0], pNode_getArgv(node));
	    _exit(EXIT_FAILURE);   // exec never returns
	}

};
/*
 * pNode_destroy returns any storage associated with `node' to the system
 */
void pNode_destroy(pNode *node){
	int i, argc = pNode_getArgc(node);
	for(i = 0; i < argc; i++){
		free(node->argvData[i]);

	}
	free(node->argvData);
	free(node->pathData);
	free(node);

};
/*
int main(int argc, char *argv[]){
	printf("%d arguments received.\n", argc);
	for (x = 0; x < argc; x++){
		printf("%d: %s\n", x, argv[x]);
	}
	char * testPath = (char*) malloc(sizeof(char) * 20);
	char ** testArg = (char**) calloc(4, sizeof(char*));
	testArg[0] = "./printer";
	testArg[1] = "4";
	testArg[2] = NULL;
	testArg[3] = NULL;
	strcpy(testPath, "x/y/z/a.out");
	printf("Creating node with: %s :: %s %s %s %s\n", testPath, testArg[0], testArg[1], testArg[2], testArg[3]);
	pNode * node = pNode_create(testPath, testArg, 3);
	printf("Created: %s :: |%d| %s %s %s\n", pNode_getPath(node), pNode_getArgc(node), pNode_getArgv(node)[0], pNode_getArgv(node)[1], pNode_getArgv(node)[2]);
	printf("PID : (%d)\n", pNode_getPID(node));
	printf("setting PID : (44)\n");
	pNode_setPID(node, 44);
	printf("new PID : (%d)\n", pNode_getPID(node));

	//execvp(pNode_getArgv(node)[0], pNode_getArgv(node));
	pid_t parent = getpid();
	pid_t pid = fork();

	if (pid == -1)
	{
	    // error, failed to fork()
	} 
	else if (pid > 0)
	{
	    int status;
	    waitpid(pid, &status, 0);
	}
	else 
	{
	    // we are the child
	    printf("insideChild\n");
	    execvp(pNode_getArgv(node)[0], pNode_getArgv(node));
	    _exit(EXIT_FAILURE);   // exec never returns
	}

	printf("we out\n");
	execvp(pNode_getArgv(node)[0], pNode_getArgv(node));
	free(testPath);
	free(testArg);
	pNode_destroy(node);

	return 0;
}
*/