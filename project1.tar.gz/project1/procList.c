#include "procList.h"
#include "procNode.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "p1fxns.h"

struct procList
{
    pNode * root;

};

/*
 * pList_create returns a new pList with a null root
 *         NULL if not (failed to allocate)
 */
pList *pList_create(void){
	pList * newList = (pList*) malloc(sizeof(pList));
	return newList;

};

/*
 * pList_insert_stdin fills the list with pNodes created from parsed stdin
 */
void pList_insert_stdin(pList *list){
	char buf[1024];
	int len, argc = 0;
	char * ptr;
	while((len = p1getline(0, buf, 1024))){
		printf("Standard Input Chars: %d\n", len);
		printf("Standard Input: %s", buf);
		for(ptr = buf;*ptr != '\0';ptr++){
			if (*ptr == ' '){
				printf("argument detected!\n");
				argc++;
			}
		}
		printf("number of arguments %d\n", argc);
		list->root = pList_insert_node(list->root, pNode_create(buf, argc));
		argc = 0;
	}
}

/*
 * pList_run runs every program in a pList 'list'
 */
void pList_run(pList *list){
	pNode * node = list->root;
	if (node == NULL){
		printf("node list is fucked up\n");
	}
	printf("here\n");
	printf("- Calling run on: %s\n", pNode_getPath(node));
	printf("here2\n");
	pNode_run(node);
	printf("- Post call note on: %s\n", pNode_getPath(node));
	while (pNode_getNext(node) != NULL){
		node = pNode_getNext(node);
		printf("- Pre call note on: %s\n", pNode_getPath(node));
		printf("- Calling run on: %s\n", pNode_getPath(node));
		pNode_run(node);
		printf("- Post call note on: %s\n", pNode_getPath(node));
	}
}


/*
 * pList_insert_node inserts a node 'node' to the list with provided root 'root'
 */
pNode * pList_insert_node(pNode * root, pNode * node){
	if (root == NULL){
		root = node;
	} else {
		pNode * temp = root;
		pNode * preTemp;
		while (temp != NULL){
			printf("Insert: Skipping %d\n", pNode_getPath(temp));
			preTemp = temp;
			temp = pNode_getNext(temp);
		}
		pNode_setNext(preTemp, node);
	}
	return root;

};


int main(int argc, char *argv[]){

	pList * list = pList_create();
	pList_insert_stdin(list);
	printf("Running processes...\n");
	pList_run(list);
	printf("Done!\n");
	printf("list traversal:\n");
	pNode * node = list->root;
	int counter = 0;
	while (node != NULL){
		printf("detected: %s\n", pNode_getPath(node));
		counter ++;
		node = pNode_getNext(node);
	}
	printf("number of pNodes in List: %d\n", counter);
	return 0;
}