#ifndef _PROCNODE_H_INCLUDED_
#define _PROCNODE_H_INCLUDED_

typedef struct procNode pNode;

/*
 * pNode_create creates a pNode structure from `buf[]` with a number of arguemnts argc
 * `buf' is an EOS terminated command to execute a program
 * returns pointer to pNode structure if successful,
 *         NULL if not (failed to run program)
 */
pNode *pNode_create(char buf[], int argc);

/*
 * pNode_getNext returns a reference to the node following provided reference 'node'
 *         NULL if no next available (no nodes remaining)
 */
pNode *pNode_getNext(pNode *node);

/*
 * pNode_setNext sets a reference to the node 'next' at the node with provided reference 'node'
 */
void pNode_setNext(pNode *node, pNode *next);


/*
 * pNode_getArgc returns the "node"'s number of arguments
 */
int pNode_getArgc(pNode *node);

/*
 * pNode_getPID returns the "node"'s process ID
 *         (-1) if no process ID is asscociated with the program (program is not on)
 */
long pNode_getPID(pNode *node);


/*
 * pNode_setPID sets the "node"'s process ID
 */
void pNode_setPID(pNode *node, long PID);

/*
 * pNode_getArgv returns the "node"'s arguments reference in the form of a NULL-Terminated array of strings (char **)
 *		with the format: {"Knock, knock.", "Who’s there?", "very long pause….", "Java.", NULL}
 *         NULL if no arguments available
 */
char ** pNode_getArgv(pNode *node);

/*
 * pNode_getArgv returns the "node"'s path reference in the form of a string (char *) with the format: "x/y/z/a.out"
 *         NULL if no path is available
 */
char * pNode_getPath(pNode *node);


/*
 * pNode_destroy returns any storage associated with `node' to the system
 */
void pNode_destroy(pNode *node);

#endif /* _PROCNODE_H_INCLUDED_ */
